/*
 * @author: Horia-George Dună
 * @id: 1949284
 * @author: Radu-Cristian Sarău
 * @id: 1939149 
 */

/**
 * This class starts the game of Snake.
*/
public class SnakeGameStart {
    public static void main(String[] args) {
        new SnakeFrame();
    }
}